/*
 * StackSolver.cpp
 *
 * This is the stack solver for SUDOKU game.
 *
 */
#include <iostream>
#include "StackSolver.h"

using namespace std;

StackSolver::StackSolver() {
}

StackSolver::~StackSolver() {
}

void StackSolver::solve() {
	// Write your own stack based solver here!
}
